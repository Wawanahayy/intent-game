# Intent RPG — MVP (Static)

RPG berbasis **intent queue**: kamu mengantri aksi (Move/Attack/Defend/Use/Interact), lalu **Resolve Tick** akan mengeksekusi semua intent berdasarkan prioritas.

- Prioritas: **Defend > Interact/Use > Move > Attack**
- Energi per tick: **3**
- Canvas: 640×400, grid 16×10

## Struktur
```
intent-rpg/
├─ index.html        # Aplikasi (tanpa build step)
├─ vercel.json       # Opsional header & clean urls
└─ .gitignore
```

## Jalankan lokal
Tanpa tooling, cukup buka `index.html` di browser modern. Atau pakai server sederhana:

```bash
# python
python -m http.server 8000
# lalu buka http://localhost:8000
```

## Deploy via GitHub → Vercel
1. Buat repo GitHub: **intent-rpg** (public/private bebas).
2. Push kode:
   ```bash
   git init
   git add .
   git commit -m "feat: Intent RPG MVP"
   git branch -M main
   git remote add origin git@github.com:USERNAME/intent-rpg.git   # ganti USERNAME
   git push -u origin main
   ```
3. Di **Vercel** (varcel): **New Project → Import GitHub Repo**.
   - Framework Preset: **Other**
   - Build Command: **(kosongkan)** — ini static
   - Output Directory: **(kosongkan)** atau `.`
   - Root Directory: **/** (default)
4. Deploy → Vercel akan memberi URL seperti `https://intent-rpg.vercel.app`.
5. (Opsional) Tambah custom domain di Project → Settings → Domains.

## Deploy via CLI (opsi alternatif)
```bash
npm i -g vercel
vercel login
vercel          # untuk first deploy (preview)
vercel --prod   # production
```

## Kustomisasi cepat
- Atur seed RNG di `new RNG(98765)`.
- Ubah map di fungsi `makeMap()`.
- Tambah jenis **Intent** dengan memasukkan COST & PRIORITY, lalu implement di `Solver.resolve()`.
